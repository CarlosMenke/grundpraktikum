# -*- coding: utf-8 -*-
"""
Created on Sat Mar 18 13:38:14 2023

@author: User
"""
import praktikum as p
import numpy as np
import matplotlib.pyplot as plt
from praktikum import cassy
from praktikum import analyse
from scipy.signal import find_peaks

plt.rcParams['font.size'] = 17.00
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = 'Arial'
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.labelsize'] = 'medium'
plt.rcParams['axes.labelweight'] = 'bold'
plt.rcParams['axes.linewidth'] = 1.2
plt.rcParams['lines.linewidth'] = 2.0

def Periodendauer(data,messung,plot=False):
    
    #einlesen der Daten
    U_a = data.messung(messung).datenreihe('U_A1').werte
    U_b = data.messung(messung).datenreihe('U_B1').werte
    t   = data.messung(messung).datenreihe('t').werte
    
    #erst Bestimmung der Spannungspeaks, sowie herausfiltern von 'doppelten' Peaks, die durch Sprünge in der Spannung entstehen
    peaks_a,_ = find_peaks(U_a,height=0.1)
    for i in range(len(peaks_a)-1):
        if abs(peaks_a[i] - peaks_a[i+1]) < 20: peaks_a[i] = 0
    peaks_a    = peaks_a[peaks_a != 0]

    peaks_b,_ = find_peaks(U_b,height=0.1)
    for i in range(len(peaks_b)-1):
        if abs(peaks_b[i] - peaks_b[i+1]) < 20: peaks_b[i] = 0
    peaks_b    = peaks_b[peaks_b != 0]
    
    #legen des ersten Spannungsmaximums auf t = 0
    t = t - t[peaks_b[0]]
    #ggf Plot zur Darstellung des Hintergrundrauschens
    if False:
        log_peaks = np.log(U_b[peaks_b])
        R,eR,b,eb,chiq,corr = p.analyse.lineare_regression(t[peaks_b], log_peaks, np.ones(len(log_peaks))*0.01)
        
        fig,ax = plt.subplots(2, 1, figsize=(10,8), sharex=True, gridspec_kw={'height_ratios': [5, 2]})
        ax[0].plot(t[peaks_b],0.435*np.exp(R*t[peaks_b]),lw=2,color = 'b')
        ax[0].plot(t[peaks_b],U_b[peaks_b],marker='o',lw=1,color = 'r',markersize=4)
        ax[0].grid()
        ax[1].set_xlabel('$t$ / s')
        ax[0].set_ylabel('$U_{max}$ / V')
        ax[1].plot(t[peaks_b],U_b[peaks_b]-0.435*np.exp(R*t[peaks_b]),lw=2,color = 'r')
        ax[1].set_ylabel('($U_{max} - U_0e^{\gamma t}$) / V')
        ax[1].axhline(y=0., color='black', linestyle='--')
        plt.show()
        
        
    #ggf Plot der Daten
    if plot:
        fig, ax = plt.subplots(2, 1, figsize=(12,10),sharex=False)
        ax[0].axhline(0,color='black',linestyle = '--', lw=1)
        ax[0].plot(t,U_a,label ='$U_{a}$', color = 'r')
        ax[0].scatter(t[peaks_a[15::15]],U_a[peaks_a[15::15]],color = 'b')
        ax[0].set_ylabel('$U$ / V')
        ax[0].legend()
        ax[1].axhline(0,color='black',linestyle = '--', lw=1)
        ax[1].plot(t,U_b,label ='$U_{b}$', color ='r')
        ax[1].scatter(t[peaks_b[9::10]],U_b[peaks_b[9::10]])
        ax[1].set_ylabel('$U$ / V')
        ax[1].set_xlabel('$t$ / ms')
        ax[1].legend()
        plt.show()
    
    #initialisieren von tmax, sigma_t , hier stehen gleich die Zeitpunkte der Peaks und deren Fehler drin
    tmax = np.array([])
    sigma_t = np.array([])
    
    #extrahieren von Datenmengen um die jeweiligen Peaks und Anwenden der Verschiebemethode
    for i in peaks_b[9::10]:
        x,y = analyse.untermenge_daten(t,U_b,t[i]-0.7,t[i]+0.7)
        t0,st = Verschiebemethode(x,y)
        tmax = np.append(tmax,t0)
        sigma_t = np.append(sigma_t,st)    
    
    return lineare_Regression(tmax,sigma_t)    
    
def Verschiebemethode(t,U,plot = False):
    #zuerst abschneiden der 'Tails' der Datenpunkte
    sel = U > 0.1
    U = U[sel]
    t = t[sel]
    
    #um die Grenzen für die Peakschwerpunkt methode varieren zu können wähle ich als Grunddaten alle die größer als -0.1 V sind und jeweils noch einen Wert 'daneben'
    sel = U > 0.15
    sel1=np.append(sel[:int(len(sel)/2):],np.array([True]))
    sel2=np.append(np.array([True]),sel[int(len(sel)/2)::])
    sel = np.append(sel1[1::],sel2[:-1:])
    U_sel = U[sel]
    t_sel = t[sel]
    
    #Bestimmen des Peakschwerpunkts mit einem symmetrischen und jeweils leicht verschobenen Intervallen
    x0 = analyse.peakfinder_schwerpunkt(t_sel[1:-1:],U_sel[1:-1:],schwelle=-1)
    x1 = analyse.peakfinder_schwerpunkt(t_sel[2:-1:],U_sel[2:-1:],schwelle=-1)
    x2 = analyse.peakfinder_schwerpunkt(t_sel[1:-2:],U_sel[1:-2:],schwelle=-1)
    x3 = analyse.peakfinder_schwerpunkt(t_sel[:-1:],U_sel[:-1:],schwelle=-1)
    x4 = analyse.peakfinder_schwerpunkt(t_sel[1::],U_sel[1::],schwelle=-1)
    
    if plot:
        fig,ax = plt.subplots(figsize=(10,7))
        ax.axvline(t_sel[2],ymin=(U_sel[2]-0.1)/0.27-0.1,ymax=(U_sel[2]-0.1)/0.27+0.1,color='cyan')
        ax.axvline(t_sel[-3],ymin=(U_sel[-3]-0.1)/0.27-0.1,ymax=(U_sel[-3]-0.1)/0.27+0.1,color='orange')
        ax.axvline(t_sel[0],ymin=(U_sel[0]-0.1)/0.27-0.1,ymax=(U_sel[0]-0.1)/0.27+0.1,color='blue')
        ax.axvline(t_sel[-1],ymin=(U_sel[-1]-0.1)/0.27-0.1,ymax=(U_sel[-1]-0.1)/0.27+0.1,color='magenta')
        ax.axhline(0.15,color='black',lw=2,linestyle='--')
        ax.plot(t,U,linestyle='--',marker='o',fillstyle = 'none',color='g')
        ax.grid()
        ax.axvline(x0,color='r',label='$t_0$')
        ax.axvline(x1,color='cyan',label='$t_1$')
        ax.axvline(x2,color='orange',label='$t_3$')
        ax.axvline(x3,color='blue',label='$t_2$')
        ax.axvline(x4,color='magenta',label='$t_4$')
        ax.legend()
        ax.set_xlabel('$t$ / s')
        ax.set_ylabel('$U$ / V')
        ax.plot(t_sel[1:-1:],U_sel[1:-1:],color='r',marker='o',markersize=5,linestyle='none')
        plt.show()
       
    #Fehler auf den maximalen Zeitpunkt ist gegeben durch den größten Abstand von dem Wert x0
    dif = abs(np.array([x1,x2,x3,x4]) - x0)
    
    return (x0,max(dif))

def lineare_Regression(y,ey,plot=False):
    
    x = np.arange(len(y))*10 +9
    #lineare Regression mit der Praktikumsbibliothek
    R,eR,b,eb,chiq,corr = p.analyse.lineare_regression(x, y, ey)
    chiq_dof=format(chiq/(len(x)-2),'.4f')
    #falls Plot = True erstellen eines Plots 
    if plot:
        # Erstelle eine schön große Abbildung mit zwei Achsenpaaren (oben für die Messdaten samt angepasster Gerade,
        # unten für den Residuenplot. Die x-Achse teilen sich beide Plots. Als Höhenverhältnis verwenden wir 5:2.
        fig, axarray = plt.subplots(2, 1, figsize=(20,10), sharex=True, gridspec_kw={'height_ratios': [5, 2]})
        
        # Grafische Darstellung der Rohdaten
        axarray[0].errorbar(x,y, yerr=ey, color='red', fmt='.', marker='o', markeredgecolor='red')
        axarray[0].set_xlabel('#$Maximum$')
        axarray[0].set_ylabel('t / s')
        axarray[0].plot(x, R*x+b, color='green',label='Regressionsgerade, $\chi^2$/dof= %s'%(chiq_dof))
        axarray[0].legend()
        
        # Zunächst plotten wir eine gestrichelte Nulllinie, dann den eigentlichen Residuenplot:
        axarray[1].axhline(y=0., color='black', linestyle='--')
        axarray[1].errorbar(x, y-(R*x+b), yerr=ey, color='red', fmt='.', marker='o', markeredgecolor='red')
        axarray[1].set_xlabel('#$Maximum$')
        axarray[1].set_ylabel('$t - (T*n +b)$ / ms ')
        
        # Wir sorgen dafür, dass die y-Achse beim Residuenplot symmetrisch um die Nulllinie ist:
        ymax = max([abs(x) for x in axarray[1].get_ylim()])
        axarray[1].set_ylim(-ymax, ymax)
        
        plt.tight_layout()
        fig.subplots_adjust(hspace=0.0)
        
        plt.show()
    return(R,eR,chiq_dof, chiq, b,eb)

T1,et1,chin1,chi1,b1,eb1 = Periodendauer(cassy.CassyDaten('M1_Stange.labx'),1)
T2,et2,chin2,chi2,b2,eb2 = Periodendauer(cassy.CassyDaten('M2_Stange.labx'),1)
T3,et3,chin3,chi3,b3,eb3 = Periodendauer(cassy.CassyDaten('M3_Stange.labx'),1)
T4,et4,chin4,chi4,b4,eb4 = Periodendauer(cassy.CassyDaten('M1_Stange_Pendelkörper.labx'),5)
T5,et5,chin5,chi5,b5,eb5 = Periodendauer(cassy.CassyDaten('M2_Stange_Pendelkörper.labx'),6)
T6,et6,chin6,chi6,b6,eb6 = Periodendauer(cassy.CassyDaten('M3_Stange_Pendelkörper.labx'),7)

print('T =',T1,';  eT = ',et1,'; chiq =',chi1,'; chiq/dof = ',chin1,' t0= ',b1,' ; et0 = ',eb1,' ')
print('T =',T2,';  eT = ',et2,'; chiq =',chi2,'; chiq/dof = ',chin2,' t0= ',b2,' ; et0 = ',eb2,' ')
print('T =',T3,';  eT = ',et3,'; chiq =',chi3,'; chiq/dof = ',chin3,' t0= ',b3,' ; et0 = ',eb3,' ')
print('T =',T4,';  eT = ',et4,'; chiq =',chi4,'; chiq/dof = ',chin4,' t0= ',b4,' ; et0 = ',eb4,' ')
print('T =',T5,';  eT = ',et5,'; chiq =',chi5,'; chiq/dof = ',chin5,' t0= ',b5,' ; et0 = ',eb5,' ')
print('T =',T6,';  eT = ',et6,'; chiq =',chi6,'; chiq/dof = ',chin6,' t0= ',b6,' ; et0 = ',eb6,' ')

T_ohne = np.array([T1,T2,T3])
et_ohne =np.array([et1,et2,et3])
T_mit = np.array([T4,T5,T6])

#gewichtetes Mittel für die Periodendauern ohne Pendelkörper mithilfe der Praktikumsbibliothek
T_ohne_v, T_ohne_std = analyse.gewichtetes_mittel(T_ohne, et_ohne)

#ungewichtetes Mittel für die Periodendauern mit Pendelkörper
T_mit_v = np.sum(T_mit)/3
T_mit_std = np.std(T_mit,ddof = 1)/np.sqrt(3)

#und die Übereinstimmung der Perioden
dif = (T_mit_v-T_ohne_v)/T_ohne_v